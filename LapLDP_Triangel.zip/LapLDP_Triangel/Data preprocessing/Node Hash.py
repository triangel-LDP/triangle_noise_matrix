# -*- coding: utf-8 -*-
def remap_nodes_and_save(input_file, output_file):
    import os

    # 读取文件并提取边
    with open(input_file, 'r') as file:
        edges = [line.strip().split() for line in file.readlines()]

    # 映射原始节点到新节点编号
    unique_nodes = sorted(set(sum(([int(edge[0]), int(edge[1])] for edge in edges), [])))
    node_map = {node: i for i, node in enumerate(unique_nodes)}

    # 创建新的边连接
    new_edges = [(node_map[int(edge[0])], node_map[int(edge[1])]) for edge in edges]

    # 保存新的边到输出文件
    with open(output_file, 'w') as file:
        for edge in new_edges:
            file.write(f"{edge[0]} {edge[1]}\n")


# 使用示例
remap_nodes_and_save('input.txt', 'output.txt')
