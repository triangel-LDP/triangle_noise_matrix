# -*- coding: utf-8 -*-
import numpy as np
import time

def read_graph_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        # 首先读取所有行来确定最大节点数
        lines = file.readlines()
        max_node = 0
        for line in lines:
            node1, node2 = map(int, line.split())
            if node1 > max_node:
                max_node = node1
            if node2 > max_node:
                max_node = node2

    # 创建足够大的邻接表数组
    adjacency_list = [[] for _ in range(max_node + 1)]
    in_list= [[] for _ in range(max_node + 1)]

    # 再次遍历所有行来构建邻接表
    for line in lines:
        node1, node2 = map(int, line.split())
        adjacency_list[node1].append(node2)
        in_list[node2].append(node1)

    return adjacency_list, in_list, max_node + 1


def create_and_update_matrix(n, b, edges):
    # 创建一个空的 n*n 矩阵
    matrix = np.zeros((n, n), dtype=np.float64)

    for i in range(n):
        for j in range(n):
            matrix[i, j] = np.random.laplace(0, b)

    for i in range(n):
        matrix[i,i] = 0

    # 使用内存中的边信息更新矩阵
    for i, j in edges:
        matrix[i, j] += 1

    return matrix



def count_triangles(adjacency_list,in_list):
    triangles = 0
    # 将每个节点按其邻接列表的长度排序
    nodes = sorted(range(len(adjacency_list)), key=lambda x: len(adjacency_list[x]))

    for node in nodes:
        outs = adjacency_list[node]
        ins=in_list[node]
        # 只检查每对邻居是否也相互连接
        for i in range(len(outs)):
            for j in range(len(ins)):
                if outs[i]!=ins[j]:
                    if ins[j] in adjacency_list[outs[i]]:
                        triangles += 1

    return triangles // 3  # 由于每个三角形被计算了三次，需要除以3






# Usage
file_path = 'directed_input.txt'
adjacency_list,in_list,n = read_graph_from_file(file_path)

epsilon_list=[5000,0.1,0.2,0.4,0.5,0.6,0.8,1.0,1.2,1.4,1.6,1.8,2.0]


MSE1=[]
MRE1=[]
MSE2=[]
MRE2=[]


true_tri=count_triangles(adjacency_list,in_list)
print("真实三角形个数：",true_tri)




def load_edges_to_memory(filepath):
    edges = []
    with open(filepath, 'r') as file:
        for line in file:
            i, j = map(int, line.strip().split())
            edges.append((i, j))
    return edges





# 加载边信息到内存
edges = load_edges_to_memory(file_path)

start_time = time.time()  # 开始计时

for eps in epsilon_list:
    print("epsilon:", eps, ":")

    list1 = []
    list2 = []
    list3 = []
    list4 = []

    for k in range(20):
        A = create_and_update_matrix(n, 1/(0.9*eps), edges)

        total = 0

        for i in range(n):
            d_i = max(len(adjacency_list[i]),len(in_list[i]))
            for j in adjacency_list[i]:
                total += A[j, :] @ A[:, i]
            laplace_noise = np.random.laplace(0, d_i / (0.1*eps))
            total += laplace_noise

        guss_tri = total / 3

        print("二轮第二种:",guss_tri)

        list1.append(abs(guss_tri - true_tri))
        list2.append((guss_tri - true_tri) ** 2)

        ################################################################################################################

        total_sum=0

        for node in range(0, n):
            outs = adjacency_list[node]
            ins=in_list[node]
            # 记录节点node的邻居

            for i in range(len(outs)):
                for j in range(len(ins)):  # 注意这里是从i+1到n，无向图点对（i，j）枚举一遍就可以了
                    total_sum += A[outs[i], ins[j]]
            # 把node的邻居之间的边加到总和里.比如若节点1有2，3，4，5，四个节点，把这四个节点之间两两组合对应在M中的值进行求和
            total_sum += np.random.laplace(0, max(len(outs),len(ins)) / (0.1*eps))

        guss_tri2=total_sum / 3
        print("二轮第一种:", guss_tri2)
        list3.append(abs(guss_tri2 - true_tri))
        list4.append((guss_tri2 - true_tri) ** 2)



    se = sum(list2) / len(list2)
    re = sum(list1) / len(list1) / true_tri

    MSE1.append(se)
    MRE1.append(re)

    print("二轮第二种:",'MSE:', se, '     MRE:', re)

    se = sum(list4) / len(list4)
    re = sum(list3) / len(list3) / true_tri

    print("二轮第一种:", 'MSE:', se, '     MRE:', re)

    MSE2.append(se)
    MRE2.append(re)
    print('\n')



print(epsilon_list)
print("二轮第一种MSE:",MSE2)
print("二轮第一种MRE:",MRE2)
print("二轮第二种MSE:",MSE1)
print("二轮第二种MRE:",MRE1)

end_time = time.time()  # 结束计时
print("总运行时间：", end_time - start_time, "秒")