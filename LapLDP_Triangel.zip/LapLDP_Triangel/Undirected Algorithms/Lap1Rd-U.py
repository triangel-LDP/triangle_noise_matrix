# -*- coding: utf-8 -*-
import numpy as np
import time
import math

def read_graph_from_file(file_path):
    adjacency_list = {}
    max_node = 0
    with open(file_path, 'r', encoding='utf-8') as file:  # 指定编码为UTF-8
        for line in file:
            node1, node2 = map(int, line.split())
            if node1 > max_node:
                max_node = node1
            if node2 > max_node:
                max_node = node2
            if node1 not in adjacency_list:
                adjacency_list[node1] = []
            if node2 not in adjacency_list:
                adjacency_list[node2] = []
            adjacency_list[node1].append(node2)

    return adjacency_list, max_node + 1


def create_and_update_matrix(n, b, edges):
    # 创建一个空的 n*n 矩阵
    matrix = np.zeros((n, n), dtype=np.float64)

    # 填充对称矩阵的下三角并镜像到上三角
    for i in range(n):
        for j in range(i + 1):
            value = np.random.laplace(0, b)  # 生成Laplace分布的随机数
            matrix[i, j] = value
            if i != j:
                matrix[j, i] = value  # 确保矩阵对称性

    for i in range(n):
        matrix[i,i] = 0

    # 使用内存中的边信息更新矩阵
    for i, j in edges:
        matrix[i, j] += 1

    return matrix



def count_triangles(adjacency_list):
    triangles = 0

    # Sort nodes by degree to minimize the intersection operation cost
    nodes = sorted(adjacency_list, key=lambda x: len(adjacency_list[x]))

    for node in nodes:
        neighbors = list(adjacency_list[node])
        # Only check for each pair of neighbors if they are also connected
        for i in range(len(neighbors)):
            for j in range(i + 1, len(neighbors)):
                if neighbors[j] in adjacency_list[neighbors[i]]:
                    triangles += 1

    return triangles/3





# Usage
file_path = 'undirected_input.txt'
adjacency_list,n = read_graph_from_file(file_path)


print(n)




epsilon_list=[100,0.1,0.2,0.4,0.5,0.6,0.8,1.0,1.2,1.4,1.6,1.8,2.0]

MSE1=[]
MRE1=[]
MSE2=[]
MRE2=[]


true_tri=count_triangles(adjacency_list)
print("真实三角形个数：",true_tri)




def load_edges_to_memory(filepath):
    edges = []
    with open(filepath, 'r') as file:
        for line in file:
            i, j = map(int, line.strip().split())
            edges.append((i, j))
    return edges

def fast_1round(A,n):
    M =math.ceil(4*math.log(n)*math.log(n))
    #M是Monte Carlo 抽样的次数


    T=[]
    #用来保存每次抽样后所取得的值。

    for i in range(M):
        x = np.random.randn(n)
        y = A @ x
        s=(y.T)@A@y/6
        #这里是算法的步骤，x是产生的一个n维标准正态随机向量。其先与矩阵A相乘得到向量y，再计算y的转置乘以A乘以y,从而使用n方的时间复杂度计算矩阵的迹，因为我们要记的是三角形个数，所以最后要除以6
        T.append(s)

    ans=sum(T)/len(T)
    #对抽样的数据取平均
    return ans



# 加载边信息到内存
edges = load_edges_to_memory(file_path)

start_time = time.time()  # 开始计时

for eps in epsilon_list:
    print("epsilon:", eps, ":")

    list1 = []
    list2 = []
    list3 = []
    list4 = []

    for k in range(10):
        A = create_and_update_matrix(n, 1/eps, edges)

        guss_tri=np.trace(np.linalg.matrix_power(A, 3)) / 6

        print("一轮:",guss_tri)

        list1.append(abs(guss_tri - true_tri))
        list2.append((guss_tri - true_tri) ** 2)

        ################################################################################################################





    se = sum(list2) / len(list2)
    re = sum(list1) / len(list1) / true_tri

    MSE1.append(se)
    MRE1.append(re)

    print("一轮:",'MSE:', se, '     MRE:', re)

    print('\n')



print(epsilon_list)
print("一轮MSE:",MSE1)
print("一轮MRE:",MRE1)

end_time = time.time()  # 结束计时
print("总运行时间：", end_time - start_time, "秒")